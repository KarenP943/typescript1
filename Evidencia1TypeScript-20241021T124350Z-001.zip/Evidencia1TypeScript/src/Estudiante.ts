export type Estudiante = {

    nombre :String;
    apellido : string;
    edad?: number | string ;
    tipoIdentificacion: string ;
    numeroIdentificacion: number | string;


}